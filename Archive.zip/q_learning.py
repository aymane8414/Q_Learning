import pygame
import numpy as np
import random
import os

# Initialisation de Pygame
pygame.init()

# Paramètres de l'environnement
WIDTH, HEIGHT = 800, 800
FPS = 60

# Couleurs
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)

# Configuration du circuit
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Q Learning car simulation")

# Hyperparamètres de Q-Learning
ALPHA = 0.1  # taux d'apprentissage
GAMMA = 0.99  # facteur de récompense future
EPSILON = 1.0  # exploration initiale
EPSILON_DECAY = 0.30
EPSILON_MIN = 0.01
Q_TABLE_PATH = "q_table.npy"

# discrétisation des états
STATE_BINS = [10, 10, 10]  # nombre de divisions pour les capteurs
MAX_SENSOR_DISTANCE = 250

# Actions
ACTIONS = [0, 1, 2]  # gauche, tout droit, droite

# Fonctions utilitaires
def draw_track():
    pygame.draw.rect(screen, GREEN, (100, 100, WIDTH - 200, HEIGHT - 200), 10)

def draw_text(surface, text, size, color, x, y):
    font = pygame.font.Font(None, size)
    text_surface = font.render(text, True, color)
    text_rect = text_surface.get_rect(topleft=(x, y))
    surface.blit(text_surface, text_rect)

class Car:
    def __init__(self):
        self.x, self.y = WIDTH // 2, HEIGHT // 2
        self.angle = 0
        self.speed = 3
        self.sensors = [0, 0, 0]

    def move(self, action):
        if action == 0:
            self.angle -= 5
        elif action == 2:
            self.angle += 5

        radian_angle = np.radians(self.angle)
        self.x += int(self.speed * np.cos(radian_angle))
        self.y -= int(self.speed * np.sin(radian_angle))

    def draw(self):
        car_rect = pygame.Rect(self.x - 15, self.y - 15, 30, 30)
        pygame.draw.rect(screen, RED, car_rect)

    def draw_sensors(self):
        radian_angle = np.radians(self.angle)
        directions = [radian_angle - np.pi / 4, radian_angle, radian_angle + np.pi / 4]

        for i, direction in enumerate(directions):
            end_x = self.x + int(self.sensors[i] * MAX_SENSOR_DISTANCE * np.cos(direction))
            end_y = self.y - int(self.sensors[i] * MAX_SENSOR_DISTANCE * np.sin(direction))
            pygame.draw.line(screen, BLUE, (self.x, self.y), (end_x, end_y), 2)

            # Dessiner un rond pour chaque capteur
            y_offset = 50 + i * 60
            if self.sensors[i] < 1:
                color = RED  # obstacle détecté
                distance_text = f"{self.sensors[i] * MAX_SENSOR_DISTANCE:.1f}"  # Affiche la distance réelle
            else:
                color = GREEN  # pas d'obstacle détecté
                distance_text = "-"  # Pas de détection

            pygame.draw.circle(screen, color, (WIDTH - 50, y_offset), 10)

            # Afficher la distance à côté du cercle
            font = pygame.font.Font(None, 16)
            text_surface = font.render(distance_text, True, BLACK)
            screen.blit(text_surface, (WIDTH - 80, y_offset - 10))

    def sense(self):
        radian_angle = np.radians(self.angle)
        directions = [radian_angle - np.pi / 4, radian_angle, radian_angle + np.pi / 4]
        max_distance = MAX_SENSOR_DISTANCE

        for i, direction in enumerate(directions):
            for d in range(max_distance):
                x = self.x + int(d * np.cos(direction))
                y = self.y - int(d * np.sin(direction))
                if x < 100 or x > WIDTH - 100 or y < 100 or y > HEIGHT - 100:
                    self.sensors[i] = d / max_distance
                    break
            else:
                self.sensors[i] = 1
        return self.sensors

    def reset(self):
        self.x, self.y = WIDTH // 2, HEIGHT // 2
        self.angle = 0
        self.sensors = [0, 0, 0]

class QLearningAgent:
    def __init__(self):
        self.q_table = self.load_q_table()
    

    def discretize_state(self, state):
        """
        Transforme les distances des capteurs (états) en catégories discrètes.
        - Exemple : Si un capteur détecte une distance de 0.5 (sur une échelle de 0 à 1),
          et qu'on divise en 10 parties égales, cela correspondra à la catégorie 5.
        """
        bins = [np.linspace(0, 1, num=b) for b in STATE_BINS] # creation des categories
        # associe chaque composante de l'état à une catégorie correspondante
        discrete_state = tuple(np.digitize(s, bins[i]) - 1 for i, s in enumerate(state))
        return discrete_state

    def choose_action(self, state):
        """
        Choisit une action pour la voiture :
        - Exploration : Avec une probabilité `EPSILON`, l'agent essaie une action au hasard
        - Exploitation : Sinon, il utilise la table Q pour choisir l'action
        """
        if random.random() < EPSILON:
            return random.choice(ACTIONS)
        discrete_state = self.discretize_state(state)
        return np.argmax(self.q_table[discrete_state])

    def update_q_table(self, state, action, reward, next_state, done):
        """
        Met à jour la table Q en fonction de l'expérience actuelle
        - L'objectif est d'apprendre combien l'action effectuée était "bonne"
        """
        discrete_state = self.discretize_state(state)
        discrete_next_state = self.discretize_state(next_state)

        q_value = self.q_table[discrete_state][action] # valeur Q actuelle pour cet état et cette action
        max_next_q = np.max(self.q_table[discrete_next_state]) # meilleur valeur Q pour l'état suivant

        # calcul de la nouvelle valeur Q
        target = reward + (GAMMA * max_next_q * (1 - done))
        self.q_table[discrete_state][action] += ALPHA * (target - q_value) # MAJ de la table

    def load_q_table(self):
        """
        Charge la table Q à partir d'un fichier ou initialise une table Q vide
        """
        if os.path.exists(Q_TABLE_PATH) and os.path.getsize(Q_TABLE_PATH) > 0:
            try:
                return np.load(Q_TABLE_PATH, allow_pickle=True)
            except EOFError:
                print("Fichier Q_TABLE corrompu. Réinitialisation de la table Q.")
        else:
            print("Fichier Q_TABLE absent ou vide. Initialisation de la table Q.")
        return np.zeros(STATE_BINS + [len(ACTIONS)])


    def save_q_table(self):
        np.save(Q_TABLE_PATH, self.q_table)


def main():
    global EPSILON
    clock = pygame.time.Clock()
    car = Car()
    agent = QLearningAgent()

    episode = 1
    score = 0
    best_score = 0

    running = True
    while running:
        screen.fill(WHITE)
        draw_track()
        car.draw()
        car.draw_sensors()

        state = car.sense()
        action = agent.choose_action(state)
        car.move(action)

        if car.x < 100 or car.x > WIDTH - 100 or car.y < 100 or car.y > HEIGHT - 100:
            reward = -10
            done = True
        else:
            reward = 1
            done = False

        next_state = car.sense()
        agent.update_q_table(state, action, reward, next_state, done)

        score += reward

        if done:
            if score > best_score:
                best_score = score
            car.reset()
            print(f"Épisode {episode} terminé avec un score de {score}. Meilleur score: {best_score}")
            episode += 1
            score = 0

            EPSILON = max(EPSILON_MIN, EPSILON * EPSILON_DECAY)

        draw_text(screen, f"Épisode: {episode}", 24, BLACK, 10, HEIGHT - 100)
        draw_text(screen, f"Score: {score}", 24, BLACK, 10, HEIGHT - 80)
        draw_text(screen, f"Meilleur score: {best_score}", 24, BLACK, 10, HEIGHT - 60)
        draw_text(screen, f"Epsilon: {EPSILON:.2f}", 24, BLACK, 10, HEIGHT - 40)

        pygame.display.flip()
        clock.tick(FPS)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                agent.save_q_table()
                running = False

    pygame.quit()

if __name__ == "__main__":
    main()
